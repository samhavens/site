# Modeling Jewish Ancestry

Open standalone.html to read and run the essay offline. Run `node --test tests/*.test.cjs` to check both models. index.md is the editorial source. historical.js runs the corrected historical screen; model.js is the separate subgroup extension. The recovered original historical Python scripts are unchanged in reference/. Reproduction commands and results are in METHODS.md and historical-reproduction.json. These are selected sensitivity scenarios, not population confidence intervals.
