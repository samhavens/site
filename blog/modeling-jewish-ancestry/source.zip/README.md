# modeling jewish ancestry

Open standalone.html to read and run the essay offline. Run `node --test tests/*.test.cjs` to check the model. index.md is the editorial source. The site build computes the default-results table from model.js. See METHODS.md and MODEL-AUDIT.md for assumptions. These are conditional cohort scenarios, not population forecasts.
